package com.example.forme_empty

import android.content.Intent
import android.graphics.Typeface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*

class WriteRecipe : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_write_recipe)

        val spinner_level = findViewById<Spinner>(R.id.spinner2)

        spinner_level.adapter = ArrayAdapter.createFromResource(
            this, R.array.vegan_level, android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner_level.adapter = adapter
        }

        spinner_level.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {

            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                println("현재 비건 단계")
            }
        }

        val MainActivityIntent = Intent(this, MainActivity::class.java)
        val saveRecipe: Button = findViewById(R.id.saveRecipe)
        saveRecipe.setOnClickListener {
            startActivity(MainActivityIntent)
        }

    }
}