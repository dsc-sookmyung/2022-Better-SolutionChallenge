package com.example.forme_empty

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class RecipeView : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recipe_view)
    }
}