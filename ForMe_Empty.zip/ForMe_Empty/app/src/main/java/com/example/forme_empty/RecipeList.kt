package com.example.forme_empty

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.forme_empty.adapter.RecommendItemAdapter
import androidx.recyclerview.widget.LinearLayoutManager.HORIZONTAL
import com.example.forme_empty.adapter.RecordItemAdapter

class RecipeList : AppCompatActivity() {
//    private lateinit var recyclerView: RecyclerView
//    private lateinit var viewAdapter: RecyclerView.Adapter<*>
//    private lateinit var viewManager: RecyclerView.LayoutManager

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recipe_list)

//        //recyclerview
//        viewManager = LinearLayoutManager(this, HORIZONTAL, true)
//        viewAdapter = RecommendItemAdapter()
//
//        recyclerView = findViewById<RecyclerView>(R.id.recycler_recipe_list).apply {
//            setHasFixedSize(true)
//            layoutManager = viewManager
//            adapter = viewAdapter
//        }

        //spinner
        val spinner_list = findViewById<Spinner>(R.id.spinner_list)

        //어댑터 연결 - array.xml에 있는 아이템 목록 추가
        spinner_list.adapter = ArrayAdapter.createFromResource(
            this, R.array.range, android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner_list.adapter = adapter
        }

        //아이템 선택 리스너
        spinner_list.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {

            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                println("최신순")
            }
        }

        val color = getColor(R.color.lightgreen)
        val white = getColor(R.color.background)
        val button2 = findViewById<Button>(R.id.button2)
        val button3 = findViewById<Button>(R.id.button3)
        val button4 = findViewById<Button>(R.id.button4)

        button2.setOnClickListener {
            button2.setBackgroundColor(color)
            button3.setBackgroundColor(white)
            button4.setBackgroundColor(white)
        }

        button3.setOnClickListener {
            button3.setBackgroundColor(color)
            button2.setBackgroundColor(white)
            button4.setBackgroundColor(white)
        }

        button4.setOnClickListener {
            button4.setBackgroundColor(color)
            button2.setBackgroundColor(white)
            button3.setBackgroundColor(white)
        }


    }




//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainViewHolder {
//        val view = LayoutInflater.from(parent.context).inflate(intId, parent, false)
//
//    }



//
//    val recommendList = RecommendDatasource().loadRecommend()
//
//    private val recipeListRecyclerView: RecyclerView by lazy {
//        view?.findViewById(R.id.recycler_recipe_list) as RecyclerView
//    }
//
//    lateinit var mainActivity: MainActivity
//    override fun onAttach(context: Context) {
//        super.onAttach(context)
//
//        // 2. Context를 Activity로 형변환하여 할당
//        mainActivity = context as MainActivity
//
//    }
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_recipe_list)
//
//    }
//
//    override fun onCreateView(
//        inflater: LayoutInflater, container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View? {
//        // Inflate the layout for this fragment
//        return inflater.inflate(R.layout.fragment_recommend, container, false)
//    }
//
//    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
//        super.onViewCreated(view, savedInstanceState)
//
//        recipeListRecyclerView.setHasFixedSize(true) //lazy접근
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            recipeListRecyclerView.layoutManager = LinearLayoutManager(context)
//            //.also { it.orientation = LinearLayoutManager.HORIZONTAL }
//        }
//        val mainViewAdapter = RecordItemAdapter(requireContext(), recommendList)
//        //성능을 개선하기 위해 다음을 설정
//        //레이아웃의 크기가 변경되지 않는 경우!에 설정
//        recipeListRecyclerView.setHasFixedSize(true)
//
//
//        recipeListRecyclerView.apply {
//            this.adapter = mainViewAdapter
//            setHasFixedSize(true)
//            val horizontalLayout = LinearLayoutManager(context)
//            horizontalLayout.orientation = LinearLayoutManager.HORIZONTAL
//            layoutManager = horizontalLayout
///*
//            val gridlayout = GridLayoutManager(context, 1)
//            layoutManager = gridlayout
//*/
//
//        }
//    }
}