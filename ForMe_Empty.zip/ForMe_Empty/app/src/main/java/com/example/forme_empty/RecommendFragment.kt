package com.example.forme_empty

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Adapter
import android.widget.Button
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.forme_empty.adapter.RecommendItemAdapter
import com.example.forme_empty.adapter.RecordItemAdapter
import com.example.forme_empty.data.RecommendDatasource

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [BoardFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class RecommendFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    // 1. Context를 받아올 변수 선언
    lateinit var mainActivity: MainActivity
    override fun onAttach(context: Context) {
        super.onAttach(context)

        // 2. Context를 Activity로 형변환하여 할당
        mainActivity = context as MainActivity

    }

    val binding by lazy { com.example.forme_empty.databinding.FragmentRecommendBinding.inflate(layoutInflater) }

    private val recipeRecyclerView: RecyclerView by lazy {
        view?.findViewById(R.id.recycler_recipe) as RecyclerView
    }

    val recommendList = RecommendDatasource().loadRecommend()
    private lateinit var adapterRecommend: RecommendItemAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }


    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_recommend, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recipeRecyclerView.setHasFixedSize(true) //lazy접근
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            recipeRecyclerView.layoutManager = LinearLayoutManager(context)
            //.also { it.orientation = LinearLayoutManager.HORIZONTAL }
        }
        val mainViewAdapter = RecordItemAdapter(requireContext(), recommendList)
        //성능을 개선하기 위해 다음을 설정
        //레이아웃의 크기가 변경되지 않는 경우!에 설정
        recipeRecyclerView.setHasFixedSize(true)


        recipeRecyclerView.apply {
            this.adapter = mainViewAdapter
            setHasFixedSize(true)
            val horizontalLayout = LinearLayoutManager(context)
            horizontalLayout.orientation = LinearLayoutManager.HORIZONTAL
            layoutManager = horizontalLayout
/*
            val gridlayout = GridLayoutManager(context, 1)
            layoutManager = gridlayout
*/

        }
    }

    override fun onStart() {
        super.onStart()

        //Button참조해서 리스너 달기
        val recipeViewButton = mainActivity.findViewById<Button>(R.id.recommend_recipe)
        val intent = Intent(getActivity(), RecipeView::class.java)
        recipeViewButton.setOnClickListener {
            startActivity(intent)
        }

        val recipeWriteButton = mainActivity.findViewById<Button>(R.id.button_write_recipe)
        val writeIntent = Intent(getActivity(), WriteRecipe::class.java)
        recipeWriteButton.setOnClickListener {
            startActivity(writeIntent)
        }

        val recipeListButton = mainActivity.findViewById<Button>(R.id.button_list_recipe)
        val listIntent = Intent(getActivity(), RecipeList::class.java)
        recipeListButton.setOnClickListener {
            startActivity(listIntent)
        }

    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment BoardFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            RecommendFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}